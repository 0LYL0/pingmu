//
//  ViewController.m
//  pingmu
//
//  Created by 刘雅兰 on 2017/7/3.
//  Copyright © 2017年 刘雅兰. All rights reserved.
//

#import "ViewController.h"
#import <SDAutoLayout.h>
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *button1;
@property (weak, nonatomic) IBOutlet UIButton *button2;
@property (weak, nonatomic) IBOutlet UIButton *button3;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.imageView.sd_layout
    .topSpaceToView(self.view, 0)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0)
    .bottomSpaceToView(self.view, 0);
    
    
    self.button1.sd_layout
    .topSpaceToView(self.view, 80)
    .centerXEqualToView(self.view);
    
    
    
    self.button2.sd_layout
//    .rightSpaceToView(self.button3, 8)
    .leftSpaceToView(self.view, 20)
    .bottomSpaceToView(self.view, 50)
   
    .heightIs(30)
    .widthIs(150);
    
    self.button3.sd_layout
    .rightSpaceToView(self.view, 20)
    .bottomSpaceToView(self.view, 50)
    .heightIs(30)
    .widthIs(150);
    
    
    
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
